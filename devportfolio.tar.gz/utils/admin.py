# This file customizes flatpages admin
# It will only work if django.contrib.flatpages is in INSTALLED_APPS
